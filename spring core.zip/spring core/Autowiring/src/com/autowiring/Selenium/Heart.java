package com.autowiring.Selenium;

public class Heart {
	public void pump()
	{
		System.out.println("Your heart is pumping");
		System.out.println("Alive");
	}

}
