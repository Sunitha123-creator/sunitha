package com.geekyscript.java;

public class Student {
 private String studentName;
 
 public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
 
 public void displayinfo()
 {
	 System.out.println("Student name is :"+studentName);
	 
 }



}
