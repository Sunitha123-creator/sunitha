package com.constructor.injection;

public class Student {
	private int idno;
	private String studentName;

	public Student(int idno,String studentName)
	{
	this.idno=idno;
	this.studentName=studentName;

	}
	public Student(int idno)
	{
	this.idno=idno;

	}

	public void displayStudentInfo() {
	System.out.println("student name is "+ studentName + " and id is : " + idno);
	}



	}


