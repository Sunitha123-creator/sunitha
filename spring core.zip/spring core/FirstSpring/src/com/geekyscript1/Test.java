package com.geekyscript1;

import org.springframework.beans.BeansException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml")) {
			HelloWorld1 helloWorld = (HelloWorld1) context.getBean("helloWorld");
			 
			  
			  System.out.println("HelloWorld bean properties: ");
			  System.out.println("Hello " + helloWorld.getMsg1());
			  System.out.println("Hello " + helloWorld.getMsg2());
			  Hellojava helloJava = (Hellojava) context.getBean("helloJava");
			  System.out.println("HelloJava bean properties: ");
			  System.out.println("Hello " + helloJava.getMsg1());
			  System.out.println("Hello " + helloJava.getMsg2());
			  System.out.println("Hello " + helloJava.getMsg3());
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			 } 

	}

