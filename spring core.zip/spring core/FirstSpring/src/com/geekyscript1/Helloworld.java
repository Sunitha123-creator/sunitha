package com.geekyscript1;

public class Helloworld {
	
	public void method()
	{
		System.out.println("Hello world");
		
		
	}

}
