package com.loosecoupling;

public class JavaCheat implements Cheat{

public void cheat() {
System.out.println("java cheating started");
}
}