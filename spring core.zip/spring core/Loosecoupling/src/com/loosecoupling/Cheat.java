package com.loosecoupling;

public interface Cheat {
	public void cheat();

}
