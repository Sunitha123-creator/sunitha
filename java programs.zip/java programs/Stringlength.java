public class Stringlength {
    public static void main(String[] args)
    {
        String s="Hello World";
        System.out.println(s.length());

    }
    
}
