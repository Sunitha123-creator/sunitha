public class JoinString {
     public static void main(String[] args) {
         String str1="Hello, ";
         String str2="How are you?";
         var result=str1.concat(str2);
         System.out.println(result);
     }
    }
    
  