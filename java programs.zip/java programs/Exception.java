
    public class Exception {
        public static void main(String[] args) {
           int a = 0, b = 10 ;
           int c = 0;
           try {
              c = b/a;
           } catch (ArithmeticException e) {
              e.printStackTrace();
              System.out.println("ArithmeticException is handled");
           }
           System.out.println("Value of c :"+ c);
        }
     }
    

    