public class String2 {
    public static void main(String args[])
    {
        StringBuffer sb1=new StringBuffer("StringBuffer");
        StringBuffer sb2=new StringBuffer("is a peer class of string");
        sb1.append(sb2);
        StringBuffer sb3=new StringBuffer("that provides much of");
        sb1.append(sb3);
        StringBuffer sb4=new StringBuffer("the functionality of strings");
        sb1.append(sb4);
        System.out.println(sb1);

    }
    
}
