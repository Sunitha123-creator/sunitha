import java.util.*;
     public class Unsupportedoperation {
        public static void main(String[] args) {
           List aList = new ArrayList();
           aList.add('a');
           aList.add('b');
           List newList = Collections.unmodifiableList(aList);
           newList.add('c');
        }
     }
    

